'use strict';
require('dotenv').config();
const { REST, Routes } = require('discord.js');
const commands = require('./src/commands/music');

const { TOKEN, CLIENT_ID, GUILD_ID, GLOBAL_COMMANDS } = process.env;
if (!TOKEN || !CLIENT_ID) throw new Error('TOKEN and CLIENT_ID are required in .env');

const rest = new REST({ version: '10' }).setToken(TOKEN);
(async () => {
  const body = commands.map(command => command.data.toJSON());
  if (GLOBAL_COMMANDS === 'true') {
    await rest.put(Routes.applicationCommands(CLIENT_ID), { body });
    console.log('Music slash commands registered globally.');
  } else {
    if (!GUILD_ID) throw new Error('GUILD_ID is required unless GLOBAL_COMMANDS=true.');
    await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), { body });
    console.log('Music slash commands registered for the configured guild.');
  }
})().catch(error => {
  console.error('Music command deployment failed:', error);
  process.exitCode = 1;
});
