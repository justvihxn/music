const fs = require('node:fs');
const path = require('node:path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const DATA_FILE = path.join(DATA_DIR, 'guild-configs.json');
const cache = new Map();
let writeQueue = Promise.resolve();

const ENV_PREFIX = String(process.env.PREFIX || ',').trim() || ',';

const DEFAULTS = Object.freeze({
  prefix: ENV_PREFIX,
  enabled: true,
  antiNukeMode: 'strict',
  protectionModules: { channelCreate: true, channelDelete: true, channelUpdate: true, roleCreate: true, roleDelete: true, roleUpdate: true, botAdd: true, ban: true, kick: true, memberUpdate: true, guildUpdate: true, webhook: true, integration: true, prune: true },
  logChannelId: null,
  punishment: 'ban',
  actionLimit: 3,
  windowMs: 10000,
  whitelist: [],
  bypassRoleIds: [],
  protectedRoleIds: [],
  lockdown: false,
  antiBotAdd: true,
  antiMassMention: true,
  antiSpam: true,
  antiDangerousRole: true,
  antiWebhook: true,
  autoRestoreChannels: true,
  createdAt: null,
  backupOwnerId: null,
  backupCodeHash: null,
  backupCodeSalt: null,
  backupCodeExpiresAt: null,
  backupCodeFailedAttempts: 0,
  backupCodeLockoutUntil: null
});

function ensureDataFile() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, '{}\n', { encoding: 'utf8', flag: 'wx' });
  }
}

function readStore() {
  ensureDataFile();
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf8');
    const parsed = JSON.parse(raw || '{}');
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      throw new Error('Expected a JSON object keyed by guild ID.');
    }
    return parsed;
  } catch (error) {
    // Do not silently overwrite a corrupt data file; that could erase every server's settings.
    throw new Error(`Could not read ${DATA_FILE}: ${error.message}`);
  }
}

let store = readStore();

class GuildConfig {
  constructor(guildId, values = {}) {
    this.guildId = String(guildId);
    Object.assign(this, structuredClone(DEFAULTS), values, { guildId: String(guildId) });
    this.protectionModules = { ...DEFAULTS.protectionModules, ...(this.protectionModules || {}) };
    this.whitelist = Array.isArray(this.whitelist) ? this.whitelist : [];
    this.bypassRoleIds = Array.isArray(this.bypassRoleIds) ? this.bypassRoleIds : [];
    this.protectedRoleIds = Array.isArray(this.protectedRoleIds) ? this.protectedRoleIds : [];
    if (!this.createdAt) this.createdAt = new Date().toISOString();
  }

  async save() {
    // Snapshot this config and serialize writes so rapid command changes don't corrupt the file.
    const snapshot = { ...this };
    writeQueue = writeQueue.then(async () => {
      store[this.guildId] = snapshot;
      ensureDataFile();
      const tempFile = `${DATA_FILE}.tmp`;
      await fs.promises.writeFile(tempFile, `${JSON.stringify(store, null, 2)}\n`, 'utf8');
      await fs.promises.rename(tempFile, DATA_FILE);
    });
    await writeQueue;
    return this;
  }
}

async function getConfig(guildId) {
  const id = String(guildId);
  if (cache.has(id)) {
    const cached = cache.get(id);
    // Migrate the old built-in '!' default to the configured PREFIX once.
    // A custom prefix set with /prefix-set is otherwise preserved.
    if (process.env.PREFIX && cached.prefix === '!' && ENV_PREFIX !== '!') {
      cached.prefix = ENV_PREFIX;
      await cached.save();
    }
    return cached;
  }
  const config = new GuildConfig(id, store[id] || {});
  if (process.env.PREFIX && config.prefix === '!' && ENV_PREFIX !== '!') config.prefix = ENV_PREFIX;
  cache.set(id, config);
  if (!store[id] || store[id].prefix !== config.prefix) await config.save();
  return config;
}

module.exports = { getConfig, DATA_FILE };
