'use strict';

const { Kazagumo } = require('kazagumo');
const { Connectors } = require('shoukaku');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, Routes } = require('discord.js');
const { getConfig } = require('./config');

const BRAND = 0x09090B;
const ACCENT = 0xA855F7;
let player;
let discordClient;
const nowPlayingMessages = new Map();
const activePlayRequests = new Map();
const recentPlayRequests = new Map();
const PLAY_DUPLICATE_WINDOW_MS = 2500;
const SEARCH_COOLDOWN_MS = 1200;
const lastSearchAt = new Map();
const voiceRecoveryInProgress = new Set();
const voiceRecoveryCooldown = new Map();

function currentTrack(p) {
  return p?.queue?.current || p?.queue?.[0] || null;
}
function upcomingTracks(p) {
  if (!p?.queue) return [];
  if (Array.isArray(p.queue)) return Array.from(p.queue);
  if (typeof p.queue.toArray === 'function') return p.queue.toArray();
  return [];
}
function durationText(ms) {
  if (!Number.isFinite(Number(ms)) || Number(ms) <= 0) return 'Live / unknown';
  const total = Math.floor(Number(ms) / 1000);
  return `${Math.floor(total / 3600) ? `${Math.floor(total / 3600)}:` : ''}${String(Math.floor((total % 3600) / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`;
}
function trackUrl(track) { return track?.uri || track?.url || ''; }
function trackDuration(track) { return track?.formattedDuration || durationText(track?.length ?? track?.durationMS); }
function musicControls(guildId, paused = false) {
  const b = (id, label, emoji, style = ButtonStyle.Secondary) => new ButtonBuilder()
    .setCustomId(`zypher_music:${id}:${guildId}`).setLabel(label).setEmoji(emoji).setStyle(style);
  return [
    new ActionRowBuilder().addComponents(
      b('back', 'Restart', '⏮️'), b(paused ? 'resume' : 'pause', paused ? 'Resume' : 'Pause', paused ? '▶️' : '⏸️', ButtonStyle.Primary),
      b('skip', 'Skip', '⏭️'), b('stop', 'Stop', '⏹️', ButtonStyle.Danger), b('queue', 'Queue', '📜')
    ),
    new ActionRowBuilder().addComponents(
      b('shuffle', 'Shuffle', '🔀'), b('loop', 'Loop', '🔁'), b('vol_down', 'Vol −', '🔉'),
      b('vol_up', 'Vol +', '🔊'), b('refresh', 'Refresh', '🔄')
    )
  ];
}
function trackEmbed(track, p, paused = false) {
  const upcoming = upcomingTracks(p).length;
  const url = trackUrl(track);
  const title = String(track?.title || 'Unknown track').slice(0, 240);
  const embed = new EmbedBuilder().setColor(ACCENT)
    .setAuthor({ name: 'Zypher Music', iconURL: 'https://zypherbot.bond/favicon.ico' })
    .setTitle(paused ? '⏸️ Playback paused' : '🎧 Now playing')
    .setDescription(`${url ? `### [${title}](${url})` : `### ${title}`}\n${track?.author ? `**Artist:** ${String(track.author).slice(0, 180)}\n` : ''}**Duration:** ${trackDuration(track)}`)
    .addFields(
      { name: '🎚️ Queue', value: `${upcoming} track${upcoming === 1 ? '' : 's'} up next`, inline: true },
      { name: '🔊 Volume', value: `${p?.volume ?? 80}%`, inline: true },
      { name: '🔁 Loop', value: String(p?.loop || 'none').toLowerCase(), inline: true }
    ).setFooter({ text: 'Zypher Music' }).setTimestamp();
  if (track?.thumbnail) embed.setThumbnail(track.thumbnail);
  return embed;
}

async function setVoiceStatus(p, status) {
  try {
    const client = discordClient;
    const channelId = p?.voiceId;
    if (!client || !channelId) return;
    await client.rest.put(Routes.channelVoiceStatus(channelId), { body: { status: status ? String(status).slice(0, 500) : null } });
  } catch (error) {
    if (error?.status !== 403 && error?.status !== 404) console.warn('[Music/Lavalink] Could not update voice status:', error.message);
  }
}
async function updateNowPlaying(p, track = currentTrack(p), paused = Boolean(p?.paused), forceNew = false) {
  if (!p || !track) return;
  const guildId = p.guildId;
  const channelId = p.textId;
  const channel = player?.client?.channels?.cache?.get(channelId);
  if (!guildId || !channel?.send) return;
  const previous = nowPlayingMessages.get(guildId);
  const payload = { embeds: [trackEmbed(track, p, paused)], components: musicControls(guildId, paused) };
  try {
    if (!forceNew && previous && previous.channelId === channel.id) {
      const message = await channel.messages.fetch(previous.messageId).catch(() => null);
      if (message) { await message.edit(payload); return; }
    }
    const message = await channel.send(payload);
    nowPlayingMessages.set(guildId, { channelId: channel.id, messageId: message.id });
  } catch (error) { console.warn('[Music/Lavalink] Could not post player card:', error.message); }
}

function initMusic(client) {
  discordClient = client;
  const host = (process.env.LAVALINK_HOST || '').trim();
  const port = Number(process.env.LAVALINK_PORT || 2333);
  const password = process.env.LAVALINK_PASSWORD || '';
  const secure = String(process.env.LAVALINK_SECURE || 'false').toLowerCase() === 'true';
  if (!host || !password) {
    console.error('[Music/Lavalink] Missing LAVALINK_HOST or LAVALINK_PASSWORD; music commands will not work until configured.');
    return null;
  }
  const node = { name: 'primary', url: `${host}:${port}`, auth: password, secure };
  player = new Kazagumo({
    defaultSearchEngine: 'youtube',
    send: (guildId, payload) => {
      const guild = client.guilds.cache.get(guildId);
      if (guild) guild.shard.send(payload);
    },
    plugins: []
  }, new Connectors.DiscordJS(client), [node], {
    resume: true,
    resumeTimeout: 60,
    reconnectTries: 5,
    restTimeout: 15_000,
    moveOnDisconnect: false
  });

  player.on('ready', (name) => console.log(`[Music/Lavalink] Node ready: ${name || 'primary'}`));
  player.shoukaku.on('ready', (name) => console.log(`[Music/Lavalink] Connected to node: ${name}`));
  player.shoukaku.on('error', (name, error) => console.error(`[Music/Lavalink] Node ${name} error:`, error?.message || error));
  player.shoukaku.on('close', (name, code, reason) => console.warn(`[Music/Lavalink] Node ${name} closed (${code}): ${reason || 'no reason supplied'}`));

  player.on('playerStart', async (p, track) => {
    p.data.set('zypherHasPlayedTrack', true);
    await updateNowPlaying(p, track, false, true);
    const artist = track.author ? ` — ${track.author}` : '';
    await setVoiceStatus(p, `🎧・${track.title}${artist} | Zypher Music`);
  });
  player.on('playerEnd', async p => {
    const track = currentTrack(p);
    if (track) await updateNowPlaying(p, track, Boolean(p.paused));
  });
  player.on('playerEmpty', async p => {
    const channel = client.channels.cache.get(p.textId);
    if (p.data.get('zypherHasPlayedTrack') && channel?.send) {
      channel.send({ embeds: [new EmbedBuilder().setColor(BRAND).setTitle('✨ Queue complete').setDescription('That was the last track. Add something new whenever you are ready.').setFooter({ text: 'Zypher Music' })] }).catch(() => {});
      p.data.set('zypherHasPlayedTrack', false);
    }
    await setVoiceStatus(p, null);
  });
  player.on('playerException', (p, data) => console.error('[Music/Lavalink] Track exception:', data?.exception?.message || data));
  player.on('playerStuck', (p, data) => console.warn('[Music/Lavalink] Track stuck:', data));
  player.on('playerResolveError', (p, track, message) => console.warn('[Music/Lavalink] Track resolve failed:', track?.title, message || 'no details'));
  player.on('playerClosed', (p, data) => {
    console.warn('[Music/Lavalink] Player connection closed:', data);

    // Discord voice close code 4006 means the voice session is no longer valid.
    // Recreate only that guild's player once per cooldown, preserving its queue.
    const guildId = p?.guildId;
    if (!guildId || ![4006, 4014].includes(Number(data?.code)) || voiceRecoveryInProgress.has(guildId)) return;
    const now = Date.now();
    // Keep recovery bounded: repeatedly recreating players can trigger Lavalink REST 429s.
    if (now - (voiceRecoveryCooldown.get(guildId) || 0) < 60_000) return;
    const guild = client.guilds.cache.get(guildId);
    if (!p.voiceId || !guild) return;
    // 4014 can mean the bot was actually disconnected. Only auto-rejoin for 24/7 mode,
    // or when Discord's cached voice state still says the bot is in the target channel.
    const botVoiceId = guild.members.me?.voice?.channelId;
    if (Number(data?.code) === 4014 && p.data?.get('stay247') !== true && botVoiceId !== p.voiceId) return;

    const snapshot = {
      guildId,
      textId: p.textId,
      voiceId: p.voiceId,
      volume: Number.isFinite(Number(p.volume)) ? Number(p.volume) : 80,
      current: currentTrack(p),
      upcoming: upcomingTracks(p),
      position: Number(p.position) || 0,
      paused: Boolean(p.paused),
      loop: String(p.loop || 'none').toLowerCase(),
      stay247: p.data?.get('stay247'),
      hasPlayed: Boolean(p.data?.get('zypherHasPlayedTrack'))
    };
    if (!snapshot.current && !snapshot.upcoming.length) return;

    voiceRecoveryInProgress.add(guildId);
    voiceRecoveryCooldown.set(guildId, now);
    (async () => {
      try {
        console.warn(`[Music/Lavalink] Recovering invalid Discord voice session for guild ${guildId}.`);
        // Drop the stale Shoukaku/Kazagumo connection before requesting a fresh one.
        player.destroyPlayer(guildId);
        await new Promise(resolve => setTimeout(resolve, 2500));
        const fresh = await player.createPlayer({
          guildId: snapshot.guildId,
          textId: snapshot.textId,
          voiceId: snapshot.voiceId,
          volume: snapshot.volume,
          deaf: true,
          mute: false
        });
        if (snapshot.current) fresh.queue.add(snapshot.current);
        for (const track of snapshot.upcoming) fresh.queue.add(track);
        if (snapshot.stay247 !== undefined) fresh.data.set('stay247', snapshot.stay247);
        fresh.data.set('zypherHasPlayedTrack', snapshot.hasPlayed);
        if (['none', 'track', 'queue'].includes(snapshot.loop)) {
          try { await fresh.setLoop(snapshot.loop); } catch {}
        }
        if (snapshot.current || snapshot.upcoming.length) {
          await fresh.play();
          // Seek only after the replacement player has had a moment to start.
          if (snapshot.position > 0 && snapshot.current?.isSeekable !== false) {
            setTimeout(() => {
              const active = player?.players?.get(guildId);
              if (active === fresh && Number.isFinite(snapshot.position)) {
                Promise.resolve(fresh.seek(snapshot.position)).catch(() => {});
              }
            }, 1200);
          }
          if (snapshot.paused) setTimeout(() => {
            const active = player?.players?.get(guildId);
            if (active === fresh) Promise.resolve(fresh.pause(true)).catch(() => {});
          }, 1500);
        }
        console.log(`[Music/Lavalink] Voice session recovered for guild ${guildId}.`);
      } catch (error) {
        console.error(`[Music/Lavalink] Voice session recovery failed for guild ${guildId}:`, error?.message || error);
      } finally {
        voiceRecoveryInProgress.delete(guildId);
      }
    })();
  });
  console.log(`[Music/Lavalink] Initialized node ${host}:${port} (TLS: ${secure})`);
  return player;
}
function getPlayer() { return player; }
function getQueue(guildId) { return player?.players.get(guildId); }
function fmtTrack(track, i) { return `${i + 1}. **${track.title}** — ${trackDuration(track)}`; }
async function reply(message, text) {
  const embed = new EmbedBuilder().setColor(BRAND).setDescription(text).setFooter({ text: 'Zypher Music' });
  return message.reply({ embeds: [embed] }).catch(() => null);
}
async function getOrCreatePlayer(guild, message, voiceChannel, volume = 80) {
  let p = getQueue(guild.id);
  if (p) {
    if (voiceChannel && p.voiceId !== voiceChannel.id) throw new Error('Join my voice channel to control this session.');
    if (message?.channel?.id && p.textId !== message.channel.id) p.textId = message.channel.id;
    return p;
  }
  if (!voiceChannel) throw new Error('Join a voice channel first, then try again.');
  return player.createPlayer({ guildId: guild.id, textId: message.channel.id, voiceId: voiceChannel.id, volume, deaf: true, mute: false });
}
async function runMusicCommand(message, name, args) {
  const guild = message.guild;
  if (!guild || !message.member) return;
  if (!player) return reply(message, 'Music is unavailable because the Lavalink node is not configured or has not initialized.');
  const voiceChannel = message.member.voice?.channel;
  let p = getQueue(guild.id);
  const needsVoice = ['play','join','skip','pause','resume','stop','leave','volume','seek','247','autoplay','shuffle','loop','remove','clear'].includes(name);
  if (needsVoice && ['play','join'].includes(name) && !voiceChannel) return reply(message, '🎙️ Join a voice channel first, then try again.');
  if (p && voiceChannel && p.voiceId && p.voiceId !== voiceChannel.id && ['play','pause','resume','skip','stop','volume','seek','shuffle','loop','remove','clear'].includes(name)) return reply(message, '🔒 Join my voice channel to control this session.');
  if (name === 'lyrics') return reply(message, 'Lyrics lookup is not enabled in this setup yet.');
  if (name === 'musichelp' || name === 'help') return reply(message, '**🎧 ZYPHER MUSIC**\n`play <song/link>` · `join` · `leave`\n`pause` · `resume` · `skip` · `stop`\n`queue` · `nowplaying` · `remove <#>` · `clear` · `shuffle`\n`volume <0-100>` · `loop <off|track|queue>` · `seek <seconds>`\n`247` · `autoplay`\nUse the player card buttons for quick controls.');

  if (name === 'play' || name === 'p') {
    const query = args.join(' ').trim();
    if (!query) return reply(message, 'Try `!play song name` or paste a supported track URL.');
    if (activePlayRequests.has(guild.id)) return reply(message, '⏳ A track is already being searched for in this server. Please wait for it to finish.');
    const requestKey = `${guild.id}:${message.author.id}`;
    const normalizedQuery = query.toLowerCase();
    const previousRequest = recentPlayRequests.get(requestKey);
    if (previousRequest?.query === normalizedQuery && Date.now() - previousRequest.at < PLAY_DUPLICATE_WINDOW_MS) return reply(message, '⏳ That search was just submitted.');
    const lastAt = lastSearchAt.get(guild.id) || 0;
    if (Date.now() - lastAt < SEARCH_COOLDOWN_MS) return reply(message, '⏳ Please wait a moment before searching again.');
    activePlayRequests.set(guild.id, true);
    lastSearchAt.set(guild.id, Date.now());
    recentPlayRequests.set(requestKey, { query: normalizedQuery, at: Date.now() });
    try {
      const guildConfig = await getConfig(guild.id);
      const stay247 = Boolean(guildConfig.music247);
      p = await getOrCreatePlayer(guild, message, voiceChannel, 80);
      // Lavalink performs resolution/streaming remotely; no local YouTube-DLP/FFmpeg child process.
      const result = await player.search(query, { requester: message.author });
      if (!result?.tracks?.length) return reply(message, `❌ No playable results found for **${query.slice(0, 100)}**.`);
      const isPlaylist = result.type === 'PLAYLIST';
      p.queue.add(isPlaylist ? result.tracks : result.tracks[0]);
      p.data.set('stay247', stay247);
      if (!p.playing && !p.paused) await p.play();
      const first = isPlaylist ? result.tracks[0] : result.tracks[0];
      return reply(message, isPlaylist
        ? `🎶 Added playlist **${result.playlistName || 'Playlist'}** (${result.tracks.length} tracks).`
        : `🎶 Added **[${first.title}](${trackUrl(first) || 'https://discord.com'} )** to the queue.`);
    } catch (error) {
      console.error('[Music/Lavalink] play failed:', error);
      return reply(message, `❌ Couldn't search or start that track. Check the Lavalink node and try another source.\n\`${String(error.message || error).slice(0, 150)}\``);
    } finally { activePlayRequests.delete(guild.id); }
  }
  if (name === 'join') {
    try { p = await getOrCreatePlayer(guild, message, voiceChannel, 80); return reply(message, `Connected to **${voiceChannel.name}**.`); }
    catch (e) { return reply(message, `Couldn't join voice: ${String(e.message || e).slice(0, 160)}`); }
  }
  if (name === 'leave' || name === 'disconnect') { if (!p) return reply(message, 'I am not in a voice channel.'); await setVoiceStatus(p, null); player.destroyPlayer(guild.id); return reply(message, '⏹️ Disconnected and cleared the queue.'); }
  if (name === 'queue' || name === 'q') {
    if (!p || (!currentTrack(p) && !upcomingTracks(p).length)) return reply(message, 'The queue is empty. Add a song with `!play`.');
    const tracks = upcomingTracks(p);
    return reply(message, `**🎶 NOW:** ${currentTrack(p) ? `[${currentTrack(p).title}](${trackUrl(currentTrack(p))})` : 'Nothing'}\n\n${tracks.slice(0, 10).map(fmtTrack).join('\n') || 'No upcoming tracks.'}${tracks.length > 10 ? `\n…and ${tracks.length - 10} more.` : ''}`);
  }
  if (name === 'nowplaying' || name === 'np') return p && currentTrack(p) ? updateNowPlaying(p) : reply(message, 'Nothing is playing right now.');
  if (!p) return reply(message, 'There is no active music session. Use `!play <song>` first.');
  if (name === 'pause') { if (p.paused) return reply(message, 'Already paused.'); await p.pause(true); return reply(message, '⏸️ Paused.'); }
  if (name === 'resume') { if (!p.paused) return reply(message, 'Playback is not paused.'); await p.pause(false); return reply(message, '▶️ Resumed.'); }
  if (name === 'skip' || name === 'next') { if (!currentTrack(p)) return reply(message, 'Nothing is playing.'); await p.skip(); return reply(message, '⏭️ Skipped.'); }
  if (name === 'stop') {
    await setVoiceStatus(p, null);
    p.queue.clear();
    // KazagumoPlayer has no stop() method. Skip the current track after clearing
    // the queue so playback ends without trying to start another queued track.
    if (currentTrack(p)) await p.skip();
    return reply(message, '⏹️ Stopped and cleared the queue.');
  }
  if (name === 'volume' || name === 'vol') { const n = Number(args[0]); if (!Number.isInteger(n) || n < 0 || n > 100) return reply(message, 'Usage: `volume <0-100>`'); await p.setVolume(n); await updateNowPlaying(p); return reply(message, `🔊 Volume set to **${n}%**.`); }
  if (name === 'shuffle') { if (upcomingTracks(p).length < 2) return reply(message, 'Add at least two upcoming tracks first.'); p.queue.shuffle(); return reply(message, '🔀 Shuffled upcoming tracks.'); }
  if (name === 'loop' || name === 'repeat') { const mode = (args[0] || 'queue').toLowerCase(); const modes = { off: 'none', none: 'none', track: 'track', song: 'track', queue: 'queue' }; if (!(mode in modes)) return reply(message, 'Usage: `loop <off|track|queue>`'); await p.setLoop(modes[mode]); await updateNowPlaying(p); return reply(message, `Loop mode: **${mode}**.`); }
  if (name === 'remove') { const n = Number(args[0]); const tracks = upcomingTracks(p); if (!Number.isInteger(n) || n < 1 || n > tracks.length) return reply(message, 'Usage: `remove <upcoming track number>`'); p.queue.remove(n - 1); return reply(message, `Removed **${tracks[n - 1]?.title || 'track'}**.`); }
  if (name === 'clear') { p.queue.clear(); return reply(message, 'Cleared upcoming tracks.'); }
  if (name === 'seek') { const seconds = Number(args[0]); if (!Number.isFinite(seconds) || seconds < 0 || seconds > 86400) return reply(message, 'Usage: `seek <seconds>`'); try { await p.seek(seconds * 1000); return reply(message, `Seeked to **${seconds}s**.`); } catch { return reply(message, 'Seeking is not supported by this track/source.'); } }
  if (name === '247') { const config = await getConfig(guild.id); config.music247 = !config.music247; await config.save(); return reply(message, `24/7 preference is now **${config.music247 ? 'ON' : 'OFF'}**. It cannot keep the bot online if the host stops it.`); }
  if (name === 'autoplay') return reply(message, 'Autoplay needs a compatible Lavalink source/plugin and is not enabled in this Lavalink migration.');
  return null;
}

async function handleMusicButton(interaction) {
  if (!interaction.isButton() || !interaction.customId.startsWith('zypher_music:')) return false;
  const [, action, guildId] = interaction.customId.split(':');
  const fail = async text => { if (!interaction.replied && !interaction.deferred) await interaction.reply({ content: text }).catch(() => {}); };
  if (!interaction.guild || interaction.guild.id !== guildId) { await fail('This player belongs to another server.'); return true; }
  const p = getQueue(guildId);
  if (!p) { await fail('This music session has ended.'); return true; }
  const userVoiceId = interaction.member?.voice?.channelId || interaction.member?.voice?.channel?.id;
  if (!userVoiceId || userVoiceId !== p.voiceId) { await fail('Join the same voice channel as Zypher to use these controls.'); return true; }
  try {
    if (action === 'pause') await p.pause(true);
    else if (action === 'resume') await p.pause(false);
    else if (action === 'skip') await p.skip();
    else if (action === 'stop') {
      await setVoiceStatus(p, null);
      p.queue.clear();
      if (currentTrack(p)) await p.skip();
    }
    else if (action === 'shuffle') { if (upcomingTracks(p).length > 1) p.queue.shuffle(); }
    else if (action === 'loop') await p.setLoop(String(p.loop).toLowerCase() === 'none' ? 'queue' : 'none');
    else if (action === 'vol_down') await p.setVolume(Math.max(0, (p.volume ?? 80) - 10));
    else if (action === 'vol_up') await p.setVolume(Math.min(100, (p.volume ?? 80) + 10));
    else if (action === 'back') await p.seek(0);
    else if (action === 'queue') {
      const tracks = upcomingTracks(p).slice(0, 10);
      await interaction.reply({ content: tracks.length ? `**Up next**\n${tracks.map(fmtTrack).join('\n')}` : 'No upcoming tracks.' });
      return true;
    }
    await updateNowPlaying(p, currentTrack(p), Boolean(p.paused));
    if (!interaction.replied && !interaction.deferred) await interaction.deferUpdate();
  } catch (error) {
    console.error('[Music/Lavalink] Button action failed:', error);
    await fail('That control failed. Try again.');
  }
  return true;
}
async function onMessage(message) {
  if (message.author.bot || !message.guild) return;
  const config = await getConfig(message.guild.id);
  const prefix = config.prefix || '!';
  if (!message.content.startsWith(prefix)) return;
  const raw = message.content.slice(prefix.length).trim();
  if (!raw) return;
  const [name, ...args] = raw.split(/\s+/);
  const aliases = { p: 'play', q: 'queue', np: 'nowplaying', vol: 'volume', next: 'skip', repeat: 'loop', disconnect: 'leave', help: 'musichelp' };
  const command = aliases[name.toLowerCase()] || name.toLowerCase();
  const known = new Set(['play','join','leave','pause','resume','skip','stop','queue','nowplaying','volume','shuffle','loop','remove','clear','seek','247','autoplay','lyrics','musichelp']);
  if (!known.has(command)) return;
  try { await runMusicCommand(message, command, args); }
  catch (error) { console.error(`[Music/Lavalink] ${command} failed:`, error); await reply(message, 'That music command failed. Check the console for details.'); }
}
module.exports = { initMusic, onMessage, getPlayer, runMusicCommand, handleMusicButton };
