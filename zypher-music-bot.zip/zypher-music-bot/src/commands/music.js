const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { runMusicCommand } = require('../music');

function optionText(interaction, name) {
  return interaction.options.getString(name) ?? '';
}
function makeCommand(name, description, options = [], handlerName = name) {
  const data = new SlashCommandBuilder().setName(name).setDescription(description);
  for (const addOption of options) data.addStringOption(addOption);
  return {
    data,
    async execute(interaction) {
      if (!interaction.inGuild()) {
        return interaction.reply({ content: 'Use this command in a server.', flags: MessageFlags.Ephemeral });
      }
      const member = interaction.member;
      if (['play', 'join'].includes(handlerName) && !member?.voice?.channel) {
        return interaction.reply({ content: 'Join a voice channel first.', flags: MessageFlags.Ephemeral });
      }
      const channel = interaction.channel;
      let replied = false;
      const fakeMessage = {
        guild: interaction.guild,
        member,
        author: interaction.user,
        channel,
        reply: async payload => {
          if (replied || interaction.deferred || interaction.replied) return interaction.followUp(typeof payload === 'string' ? { content: payload } : payload);
          replied = true;
          return interaction.reply(typeof payload === 'string' ? { content: payload } : payload);
        }
      };
      const args = [];
      if (name === 'play') args.push(optionText(interaction, 'song'));
      if (name === 'volume') args.push(optionText(interaction, 'amount'));
      if (name === 'loop') args.push(optionText(interaction, 'mode') || 'queue');
      if (name === 'remove') args.push(optionText(interaction, 'position'));
      if (name === 'seek') args.push(optionText(interaction, 'seconds'));
      try {
        await runMusicCommand(fakeMessage, handlerName, args);
        if (!replied && !interaction.replied && !interaction.deferred) {
          await interaction.reply({ content: 'Done.', flags: MessageFlags.Ephemeral });
        }
      } catch (error) {
        console.error(`[Music] /${name} failed:`, error);
        const payload = { content: 'That music command failed. Check the bot console for details.', flags: MessageFlags.Ephemeral };
        if (interaction.replied || interaction.deferred) await interaction.followUp(payload).catch(() => {});
        else await interaction.reply(payload).catch(() => {});
      }
    }
  };
}

const required = (name, description) => o => o.setName(name).setDescription(description).setRequired(true);
const optional = (name, description) => o => o.setName(name).setDescription(description).setRequired(false);

const commands = [
  makeCommand('play', 'Play a song or supported audio URL', [required('song', 'Song name or YouTube, Spotify, SoundCloud link')]),
  makeCommand('join', 'Join your voice channel'),
  makeCommand('leave', 'Leave the voice channel and clear the queue'),
  makeCommand('pause', 'Pause the current track'),
  makeCommand('resume', 'Resume playback'),
  makeCommand('skip', 'Skip the current track'),
  makeCommand('stop', 'Stop playback and clear the queue'),
  makeCommand('queue', 'Show the current music queue'),
  makeCommand('nowplaying', 'Show the current track'),
  makeCommand('volume', 'Set playback volume', [required('amount', 'Volume from 0 to 100')]),
  makeCommand('shuffle', 'Shuffle upcoming tracks'),
  makeCommand('loop', 'Set loop mode', [o => o.setName('mode').setDescription('Loop mode').setRequired(true).addChoices({name:'Off',value:'off'},{name:'Track',value:'track'},{name:'Queue',value:'queue'})]),
  makeCommand('remove', 'Remove an upcoming track by its queue position', [required('position', 'Upcoming track number, starting at 1')]),
  makeCommand('clear', 'Clear upcoming tracks'),
  makeCommand('seek', 'Seek to a position in seconds when supported', [required('seconds', 'Position in seconds')]),
  makeCommand('music247', 'Toggle the 24/7 preference', [], '247'),
  makeCommand('autoplay', 'Toggle autoplay where supported'),
  makeCommand('lyrics', 'Show lyrics feature availability', [], 'lyrics'),
  makeCommand('musichelp', 'Show music commands')
];

module.exports = commands;
