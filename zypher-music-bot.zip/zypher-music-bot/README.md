# Zypher Music Bot — standalone extraction

This project separates the music files from the supplied bot archive into a dedicated Discord bot. The original archive/files are not modified. The music module, music command module, and config module are copied from the archive; only the startup and slash-command deployment entry points are standalone wrappers.

## Setup

1. Create a **separate Discord application/bot** for this music bot in the Discord Developer Portal.
2. Copy `.env.example` to `.env` and fill in the new bot token, application ID, test guild ID, and the Lavalink connection values.
3. In the Developer Portal, enable **Message Content Intent** for prefix commands. Invite the bot with `bot` and `applications.commands` scopes and permissions to view/send messages, connect, speak, and use voice.
4. Install Node.js 18.18 or newer, then run:

   ```bash
   npm install
   npm run check
   npm run deploy
   npm start
   ```

5. Prefix commands use the configured `PREFIX` (the supplied music config defaults to a comma if unset). Slash commands are registered from `src/commands/music.js`.

## Lavalink

The bot requires a reachable Lavalink server and compatible audio source support. `LAVALINK_SECURE=true` is appropriate when connecting through TLS/WSS (commonly port 443); use the host/provider's exact connection details.

## Important

- Do not reuse the same bot token for the original bot and this standalone bot. Discord allows one active gateway session per token, and they can disconnect each other.
- This extraction does not modify the original bot or the supplied source archive.
- The copied music system's behavior and commands are preserved; only the boot/deployment wiring is made standalone.
