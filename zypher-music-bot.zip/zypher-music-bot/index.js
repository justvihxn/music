'use strict';
require('dotenv').config();

const {
  Client, GatewayIntentBits, Partials, Collection, Events
} = require('discord.js');
const { initMusic, onMessage, handleMusicButton } = require('./src/music');
const musicCommands = require('./src/commands/music');

if (!process.env.TOKEN) throw new Error('TOKEN missing: configure .env');
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates
  ],
  partials: [Partials.Channel, Partials.Message]
});

client.commands = new Collection();
for (const command of musicCommands) client.commands.set(command.data.name, command);

initMusic(client);

client.on(Events.MessageCreate, message => {
  onMessage(message).catch(error => console.error('[Music] Prefix command error:', error));
});

client.on(Events.InteractionCreate, async interaction => {
  if (interaction.isButton()) {
    try {
      if (await handleMusicButton(interaction)) return;
    } catch (error) {
      console.error('[Music] Button handler error:', error);
    }
  }

  if (!interaction.isChatInputCommand()) return;
  const command = client.commands.get(interaction.commandName);
  if (!command) return;
  try {
    await command.execute(interaction);
  } catch (error) {
    console.error(`[Music] /${interaction.commandName} failed:`, error);
    const payload = { content: 'That music command failed. Check the bot console for details.' };
    try {
      if (interaction.replied || interaction.deferred) await interaction.followUp(payload);
      else await interaction.reply(payload);
    } catch {}
  }
});

client.once(Events.ClientReady, c => {
  console.log(`[READY] ${c.user.tag} | guilds: ${c.guilds.cache.size}`);
  c.user.setPresence({ activities: [{ name: '🎧 Music | /musichelp' }], status: 'online' });
});

client.on('error', error => console.error('[Discord client]', error));
process.on('unhandledRejection', error => console.error('[unhandled rejection]', error));

client.login(process.env.TOKEN).catch(error => {
  console.error('[startup]', error);
  process.exit(1);
});
